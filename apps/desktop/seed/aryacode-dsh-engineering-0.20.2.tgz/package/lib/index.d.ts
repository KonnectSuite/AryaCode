/** Host half of the engineering bundle: registers nothing; the patch and the client face do the work. */
export declare function apply(): void
