/** Identities of checksum-verified Arya release files in a profile cache. */
export interface CachedAryaRelease {
    version: string;
    sha256: string;
}
/** Content-addressed file name for a published package. */
export declare function aryaReleaseFile(name: string, release: CachedAryaRelease): string;
/** Recognize a market-owned release cache spec instead of a development checkout. */
export declare function isAryaReleaseSpec(plugin: {
    name: string;
    releases?: CachedAryaRelease[];
}, spec: string): boolean;
/** A published release as the catalog records it. */
export interface PublishedRelease {
    version: string;
    tarball?: string;
}
/**
 * Whether a manifest spec already names one of this entry's released builds.
 *
 * A release installs from its tarball URL or from the cache file the market
 * staged, but pnpm rewrites the manifest to the version it resolved — so a
 * plugin that came from this catalog is stored as `0.114.0` or `^0.114.0`.
 * Treating only the tarball URL as "the same published source" made that
 * rewrite permanent: the next update asked for "a released version explicitly",
 * which the update dialog never sends, so the plugin could never move again.
 * @param plugin - Catalog entry whose releases were published.
 * @param spec - Dependency spec as the profile records it.
 * @returns true when the spec resolves to a version this entry published.
 */
export declare function isPublishedReleaseSpec(plugin: {
    releases?: PublishedRelease[];
}, spec: string): boolean;
