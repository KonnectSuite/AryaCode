/** Identities of checksum-verified Arya release files in a profile cache. */
export interface CachedAryaRelease {
    version: string;
    sha256: string;
}
/** Content-addressed file name for a published package. */
export declare function aryaReleaseFile(name: string, release: CachedAryaRelease): string;
/** Recognize a market-owned release cache spec instead of a development checkout. */
export declare function isAryaReleaseSpec(plugin: {
    name: string;
    releases?: CachedAryaRelease[];
}, spec: string): boolean;
