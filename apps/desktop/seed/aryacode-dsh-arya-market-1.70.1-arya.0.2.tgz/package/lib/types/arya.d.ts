import type { Registry, RegistryPlugin } from './registry.ts';
/** One packaged release; targets are approved by the catalog publisher. */
export interface AryaRelease {
    version: string;
    tarball: string;
    sha256: string;
}
/** Catalog shipped and maintained by the Arya fork.
 *
 * The catalog is generated data that changes on every publish, so it lives on
 * its own `catalog` branch. Pinning a feature branch here would make the URL a
 * reason never to restructure branches.
 */
export declare const ARYA_CATALOG_URL = "https://raw.githubusercontent.com/KonnectSuite/dsh-arya-market/catalog/data/arya-plugins.json";
/** Validate a configured catalog address before mounting HTTP routes. */
export declare function validateCatalogUrl(value: string): void;
/** Reject malformed release records at the external catalog input. */
export declare function validateAryaRegistry(registry: Registry): Registry;
/** Combine community browsing with validated Arya releases; Arya owns duplicate names.
 * @param community - Third-party catalog without Arya release authority.
 * @param arya - Catalog whose packaged releases must pass Arya validation.
 * @returns Community entries and authoritative Arya packages with combined categories.
 */
export declare function mergeMarketRegistries(community: Registry, arya: Registry): Registry;
/** Download limits resolved from the host's validated market configuration. */
export interface AryaDownloadLimits {
    maxBytes: number;
    timeoutMs: number;
}
/** Cancellation requested before a verified archive reached the installer. */
export declare class AryaReleaseCancelled extends Error {
    constructor();
}
/** Validate deployment limits before accepting package operations. */
export declare function validateAryaDownloadLimits(limits: AryaDownloadLimits): void;
/** Resolve and validate the host's deployment-specific download limits. */
export declare function resolveAryaDownloadLimits(config: {
    maxReleaseBytes?: number;
    releaseDownloadTimeoutMs?: number;
}): AryaDownloadLimits;
/**
 * Stage verified release bytes for pnpm versions that omit remote archive integrity.
 * @param plugin - Validated catalog package.
 * @param version - Listed release version.
 * @param profileDirectory - Profile that owns the persistent content cache.
 * @param limits - Resolved size and elapsed-time limits.
 * @param signal - Optional owner cancellation signal.
 * @returns Absolute file target accepted by the existing installer.
 */
export declare function stageAryaRelease(plugin: RegistryPlugin, version: string, profileDirectory: string, limits: AryaDownloadLimits, signal?: AbortSignal): Promise<string>;
/** Select only a listed release; omission chooses the publisher's first release. */
export declare function aryaReleaseTarget(plugin: RegistryPlugin, version?: unknown): string;
/** Read the installer-owned package version, independently of the active profile override.
 *
 * `installDir` is the directory of the running dsh package itself, so a Desktop
 * installer keeps its bundles either beside that package or at the runtime's
 * hoisted node_modules root; both layouts are read.
 */
export declare function bundledAryaVersion(installDir: string | undefined, name: string): string | null;
